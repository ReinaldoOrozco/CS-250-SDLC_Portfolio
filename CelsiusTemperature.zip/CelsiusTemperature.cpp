/*
	Author: Reinaldo Orozco Rodriguez
	Program: Fahrenheit to Celsius Converter
	Description:
		This program reads the city temperatures data from the FahrenheitTemperature.txt,
		and converts each temperature to Celsius and also writes the results
		to CelsiusTemperature.txt. Demonstrate file I/O, data processing and industry-standard
		practices.
*/
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
// This is the mathemathical formula for the conversion of Fahrenheit to Celsius 

double convertFtoC(int fahrenheit) {
	return (fahrenheit - 32) * 5.0 / 9.0;
}

int main() {

	/* 
		1A. Open the Input File for reading.
	*/ 

	ifstream inputFile("FahrenheitTemperature.txt");

	/*
		1B. Make sure the file open correctly.
	*/

	if (!inputFile.is_open()) {
		cout << "Error: Could not open FahrenheitTemperature.txt";
		return 1; // This will exit the program if file cannot be oppened.

	}

	/*
	* 2A. Open the Output File for writing.
	*/

	ofstream outputFile("CelsiusTemperature.txt");

	/*
		2B. Make sure the file open correctly.
	*/

	if (!outputFile.is_open()) {
		cout << "Error: Could not create CelsiusTemperature.txt";
		return 1;
	}

	string cityName; //This will store the city name.

	int tempF;		//This will store the Fahrenheit Temperature.

	/*
	*  3A. This will read the city and the temperature until the file ends
	*/
	
	while (inputFile >> cityName >> tempF) {

		/*
		*	3B. Conversion code from Fahrenheit to Celsius.
		*/

		double tempC = convertFtoC(tempF);

		/*
		*	4A. Here it will wirte the city and celsius temperature
		*/
		outputFile << cityName << " " << tempC << endl;
	}

	/*
	*	Close Both Files.
	*/

	inputFile.close();
	outputFile.close();

	cout << " Conversion Complete. Check the CelsiusTemperature.txt for results." << endl;

	return 0;
}